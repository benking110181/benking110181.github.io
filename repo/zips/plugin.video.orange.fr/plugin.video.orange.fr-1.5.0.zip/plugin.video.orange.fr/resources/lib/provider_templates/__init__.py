# -*- coding: utf-8 -*-
# pylint: disable=missing-module-docstring
from .orange import OrangeTemplate

import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.vstream/?site=cGui&function=viewInfo)", True)
